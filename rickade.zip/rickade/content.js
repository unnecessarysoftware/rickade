const redirectUrl = "https://www.youtube.com/watch?v=dQw4w9WgXcQ";  // Hedef URL’yi buraya ekleyin
const currentUrl = window.location.href;

// Kullanıcıyı yönlendir

if (!currentUrl.includes("https://www.youtube.com/watch?v=dQw4w9WgXcQ")) {
  window.location.href = redirectUrl;
}